import {StyleSheet} from 'react-native';

export default StyleSheet.create({

    container: {
        flex: 1, 
        alignItems: 'center',
    },

    title: {

    },

    logo: {
        flex: 1, 
        width: 100,
        height: 100,
        alignSelf: 'center',
        margin: 30,
        borderRadius:50
    },

    input: {
        height: 48,
        borderRadius: 50,
        overflow: 'hidden',
        backgroundColor: '#f2f2f2',
        marginTop: 10,
        marginBottom: 10,
        marginLeft: 30,
        marginRight: 30,
        paddingLeft: 16,

    },

    button: {
        backgroundColor: '#8ec739',
        marginTop: 10,
        marginBottom: 10,
        marginLeft: 30,
        height: 60,
        marginRight: 30,
        borderRadius: 5,
        alignItems: 'center',
        justifyContent: 'center',

    },

    buttonTitle: {
        flex: 1,
        alignItems: 'center',
        marginTop: 15,
        fontSize: 20,
        color:"#ffff"
    },

    footerView: {
        flex: 1,
        alignItems: 'center',
        marginTop: 20,
    },

    footerText: {
        fontSize: 20,
        color: '#2e2e2d',
        textAlign: 'center',
        marginTop: 20,

    },

    footerLink: {
        fontSize: 20,
        color: '#8ec739',
        fontWeight: 'bold',
    },

});